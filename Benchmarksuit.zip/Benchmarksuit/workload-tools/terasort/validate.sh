#!/bin/bash

TeraSort_OUTPUT="/data/terasort_output"
TeraSort_VALIDATE="/data/terasort_validate"
jar=spark-terasort-1.1-SNAPSHOT-jar-with-dependencies.jar

spark-submit --class com.github.ehiggs.spark.terasort.TeraValidate $jar $TeraSort_OUTPUT $TeraSort_VALIDATE
