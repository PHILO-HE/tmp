#!/bin/bash

TeraSort_INPUT="/data/terasort_input"
#HADOOP_JAR=/hadoop/share/hadoop/mapreduce/hadoop-mapreduce-examples-3.3.0-SNAPSHOT.jar
SIZE=1g
jar=spark-terasort-1.1-SNAPSHOT-jar-with-dependencies.jar

#hadoop jar $HADOOP_JAR teragen -D mapreduce.job.queuename=root.root $SIZE $TeraSort_INPUT
spark-submit --class com.github.ehiggs.spark.terasort.TeraGen $jar $SIZE $TeraSort_INPUT
