#!/bin/bash

usage(){
        echo "Usage: ./validate.sh result_dir baseline_result_dir"
        exit 1
}

if [ $# -lt 2 ]
then
        usage
fi


validate_result_dir=$1
baseline_result_dir=$2

log_dir=query
validate_files=`ls ${validate_result_dir}/${log_dir} | grep out`

for file in $validate_files
do
	if [ ! -f "${baseline_result_dir}/${log_dir}/${file}" ]; then
		echo "Baseline results do not contain ${file}"
	else
		cksum_validate=`cksum ${validate_result_dir}/${log_dir}/${file} | awk '{print $1}'`
		cksum_baseline=`cksum ${baseline_result_dir}/${log_dir}/${file} | awk '{print $1}'`
		if [ $cksum_validate -ne $cksum_baseline ]; then
			echo "Query result is different from base line: ${file}"
		fi
	fi
done
