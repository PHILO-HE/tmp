**data_gen.scala**: data generation code works with spark-sql-perf. Usage: `cat data_gen.scala | spark-shell --jars spark-sql-perf_2.12-0.5.1-SNAPSHOT.jar`

**table_gen.sql**: script to load external TPCDS tables as Hive table. Usage: `spark-sql -d DB=$DB_name -d LOCATION=$DB_location -f table_gen.sql`

**validate.sh**: script to validate query results. Make sure you generate TPC-DS data with Decimal format. Make sure the result was collected by this benchmark kit, since this script can only work with specific directory structure. Usage: `./validate.sh result_dir baseline_result_dir`
