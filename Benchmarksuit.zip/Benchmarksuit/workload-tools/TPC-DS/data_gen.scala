import com.databricks.spark.sql.perf.tpcds.TPCDSTables

val scaleFactor = "1" // scaleFactor defines the size of the dataset to generate (in GB).
val numPartitions = 100
val databaseName = s"tpcds_spark_$scaleFactor"

// Set:
val rootDir =  s"s3a://tpcds/$databaseName" // root directory of location to create data in.
val format = "parquet" // valid spark format like parquet "parquet".
val dsdgenDir = "/tmp/tpcds-kit/tools" // location of dsdgen
// Run:
val tables = new TPCDSTables(spark.sqlContext,
    dsdgenDir = dsdgenDir, // location of dsdgen
    scaleFactor = scaleFactor,
    useDoubleForDecimal = false, // true to replace DecimalType with DoubleType
    useStringForDate = false) // true to replace DateType with StringType


tables.genData(
    location = rootDir,
    format = format,
    overwrite = true, // overwrite the data that is already there
    partitionTables = true, // create the partitioned fact tables, set false for text
    clusterByPartitionColumns = true, // shuffle to get partitions coalesced into single files. 
    filterOutNullPartitionValues = true, // true to filter out the partition with NULL key value
    tableFilter = "", // "" means generate all tables
    numPartitions = numPartitions) // how many dsdgen partitions to run - number of input tasks.

// Create the specified database
sql(s"create database $databaseName")
// Create metastore tables in a specified database for your data.
// Once tables are created, the current database will be switched to the specified database. set discoverPartitions=false for text
tables.createExternalTables(rootDir, format, databaseName, overwrite = true, discoverPartitions = true)
// Or, if you want to create temporary tables
// tables.createTemporaryTables(location, format)

// For CBO only, gather statistics on all columns:
//tables.analyzeTables(databaseName, analyzeColumns = true)
