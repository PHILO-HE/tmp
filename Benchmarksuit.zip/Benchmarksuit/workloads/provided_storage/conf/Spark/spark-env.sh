#export HADOOP_HOME=/hadoop
#export HADOOP_CONF_DIR=/hadoop/etc/hadoop/
#export SPARK_DIST_CLASSPATH=$(/hadoop/bin/hadoop classpath)
#export JAVA_HOME=/usr/java/jdk1.8.0_121

export HADOOP_HOME=/hadoop
export HADOOP_CONF_DIR=/hadoop/etc/hadoop/
export SPARK_DIST_CLASSPATH=$(/hadoop/bin/hadoop classpath)
export JAVA_HOME=/usr/java/jdk1.8.0_121
export SPARK_WORKER_CORES=50
export SPARK_WORKER_MEMORY=100GB
