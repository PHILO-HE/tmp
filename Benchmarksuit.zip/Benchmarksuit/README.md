# Benchmarksuit
Workload execution and test performance system metrics collection toolkit.

We use [PAT](https://github.com/asonje/PAT) to collect system metrics and process metrics data.

# Components
**pat-suite**: it is a test suite which can execute test scripts and collect system performance metrics at the same time.

**PAT-post-processing**: it is a tool to postprocess performance data collected by pat-suite. For detail usage, please refer to [PAT](https://github.com/asonje/PAT)

**workload-tools**: some workload related scripts for reference.

**workloads**: this suite supports HDFS_cache, PMoF and HDFS provided storage workloads. We provide some recommended configurations here.
