#!/bin/bash
source basic.sh

runid=$1
#prepare log dir
log_dir=/tmp/log_${runid}
mkdir $log_dir
runid=${runid}_`date +"%Y-%m-%d-%s"`
echo [$HOSTNAME][$0][`date +"%Y-%m-%d %T"`] RunID=$runid

# for every node in the physical bluedata cluster
all_hosts=$(awk '(/^ALL_NODES/){for (i=2; i<=NF; i++) print $i}' ./config)
for host in $all_hosts;do
    echo [$HOSTNAME][$0][`date +"%Y-%m-%d %T"`] Preparing $host ...
    #ssh $host "echo 1 > /proc/sys/vm/drop_caches"
    #ssh $host ps -ef|grep pat_tmp |awk '{print $2}'|xargs kill -9
    ssh $host "echo 3 > /proc/sys/vm/drop_caches"
    # If you want to clear the cache, just run below command.
    #ssh $host "echo 1 > /proc/sys/vm/drop_caches" &
done

export runid
export log_dir
