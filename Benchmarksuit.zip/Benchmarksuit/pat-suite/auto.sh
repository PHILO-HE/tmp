#!/bin/bash
source basic.sh

printUsage(){
    echo "Usage: ./auto runid"
    exit -1
}


if [ $# -lt 1 ]
then 
    printUsage
#elif [ `find ./workload -type f -name $1|wc -l` -ne 1 ] 
#then
#    echo "Workload can't be found."
#    exit -1
fi 

#exit
loop=1
if [ "$2" != "" ]
then
    loop=$2
fi
echo "loop = $loop"

head=`get_hosts|awk '{print $1}'`
work_dir=$(pwd)
export work_dir

echo "head;"$head
for((i=0;i<$loop;i++))
do
	source ./workload_prepare.sh
	./pat run ${runid}
	source ./workload_teardown.sh
	echo "*****************loop $i done******************"
done
