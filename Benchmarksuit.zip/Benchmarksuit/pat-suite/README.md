# Collection system provision
To use the tool, make all your edits within the "./config" file.

Be sure to edit the following parameters: 
- ALL_NODES          (this needs to be in a format of <hostname>:<port>; the port
                    is expected to be the port ID of the SSH port, which is often 22)
- WORKER_SCRIPT_DIR  (where worker scripts will live on each worker node)
- WORKER_TMP_DIR     (where workers will store temporary files on each node)
- CMD_PATH           (the script which will launch the workload)

# Test suite provision
Edit or put your scripts under pat-suite/workload foler at first.

# Start
./auto [runid]

# Result
Results will be store into pat-suite/results/$runid-$timestamp, also you can use PAT-post-processing tool to process collected data.

You can copy instruments under each result folder into your windows system, then issue "ctrl+q" to execute the excel macro after open "result_templatev1.xlsm" to generate graph result of system metrics.
