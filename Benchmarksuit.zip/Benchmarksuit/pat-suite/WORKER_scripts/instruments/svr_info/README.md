svr_info
===
**See the svr_info home page on Inside Blue at [goto/svr_info](https://goto/svr_info). 
To download the latest release, see this repo's [Tags](https://gitlab.devtools.intel.com/cloud/svr_info/tags) page.**

**Note**: If you want to clone the repo and run from source, you must run **'make'** to 
build a complete runnable package. The build creates two packages in the dist/ folder.
See [Makefile](https://gitlab.devtools.intel.com/cloud/svr_info/blob/master/Makefile[]([url](url))) if you are curious.
