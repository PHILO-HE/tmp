#!/bin/bash
VERSION="SVRINFO_DEV_VERSION"
SCRIPT_NAME=`basename $0`

usage(){
  # usage is populated by Makefile from usage.txt
  printf "\nThis is a development version.\n"
}

if [ $# -eq 1 ]; then 
  case $1 in
    "--help") usage ;;
    "-h") usage ;;
    "--clean") true ;;
    *) echo Invalid argument used: $1; usage ;;
  esac
  exit 1
fi

export TMPDIR=`mktemp -d rundir.XXXXXX`

ARCHIVE=`awk '/^__ARCHIVE_BELOW__/ {print NR + 1; exit 0; }' $0`

tail -n+$ARCHIVE $0 | tar xzv -C $TMPDIR >/dev/null 2>&1

SDIR=`pwd`
cd $TMPDIR/svr_info
./svr_info.sh "$@"

cd $SDIR
TODAY="$( date +"%Y%m%d" )"
INDEX=0
RESULTS_DIR="$HOSTNAME.$TODAY"
while [ -d $RESULTS_DIR ]; do
  INDEX=$(( $INDEX + 1 ))
  RESULTS_DIR="$HOSTNAME.$TODAY.$INDEX"
done
if [ -f $TMPDIR/svr_info/svr_info_out.tar.gz ]; then
  mkdir $RESULTS_DIR
  cp $TMPDIR/svr_info/svr_info_out.tar.gz $RESULTS_DIR
  tar -xf $RESULTS_DIR/svr_info_out.tar.gz -C $RESULTS_DIR
  printf "\nResults can be found in $RESULTS_DIR.\n\n"
fi

rm -rf $TMPDIR
exit 0

__ARCHIVE_BELOW__
