#!/usr/bin/env python
from __future__ import print_function
import os, sys, argparse
import json

sys.path.insert(
    0, os.path.abspath(os.path.join(os.path.split(__file__)[0], "..", ".."))
)
from rpt.svrinfo import Svrinfo

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate svr_info json report.")
    parser.add_argument("-i", "--input", help="Raw svr_info log", required=True)
    parser.add_argument(
        "-o", "--output", help="filename for json report", required=True
    )
    args = vars(parser.parse_args())
    if not os.path.isfile(args["input"]):
        raise SystemExit("File not found: " + args["input"])

    s = Svrinfo(args["input"])

    my_dict = {}

    def get_section(sdict, label):
        if not sdict:
            return
        for k in sdict:
            if k.startswith("Reference_Intel"):
                continue
            if k in my_dict:
                my_dict[k][label] = sdict[k]
            else:
                my_dict[k] = {label: sdict[k]}

    get_section(s.get_mem(), "mem")
    get_section(s.get_cpu(), "cpu")
    get_section(s.get_sysd(), "sysd")
    get_section(s.get_security_vuln(), "security_vuln")
    get_section(s.get_calc_freq(), "calcfreq")
    get_section(s.get_sys(), "sys")
    get_section(s.get_sensors(), "sensors")
    get_section(s.get_chassis_status(), "chassis_status")
    get_section(s.get_cpu_family(), "cpu_family")
    get_section(s.get_health(), "health")
    get_section(s.get_system_event_log(), "system_event_log")

    # Net
    for k, v in s.get_net().items():
        if k.startswith("Reference_Intel"):
            continue
        if v:
            # v is a dictionary: {attribute: [value1, value2]}
            my_dict[k]["net"] = {}
            for idx in range(len(v["Name"])):
                ifc = {}
                for attribute in v.keys():
                    try:
                        ifc[attribute] = v[attribute][idx]
                    except IndexError:
                        pass
                my_dict[k]["net"][str(idx)] = ifc

    # DIMMs
    for k, v in s.get_dimms().items():
        if k.startswith("Reference_Intel"):
            continue
        if v:
            # v is a list of dictionary
            my_dict[k]["dimms"] = {}
            for idx, dimm in enumerate(v):
                my_dict[k]["dimms"][str(idx)] = dimm

    # Loaded latency
    for k, v in s.get_loadlat().items():
        if k.startswith("Reference_Intel"):
            continue
        if v:
            # v is a list of: [delay, latency, bandwidth]
            my_dict[k]["mem_max_bandwidth"] = str(max(int(m[2]) for m in v))
            my_dict[k]["mem_bandwidth_latency"] = {}
            for m in v:
                my_dict[k]["mem_bandwidth_latency"][m[2]] = m[1]

    # NUMA bandwidth
    for k, v in s.get_mlc_bandwidth().items():
        if k.startswith("Reference_Intel"):
            continue
        if v:
            # v is a list of tuple: (node, {nodea: bandwidth, nodeb: bandwidth, ...})
            my_dict[k]["mem_numa_bandwidth"] = {}
            for node in v:
                my_dict[k]["mem_numa_bandwidth"][node[0]] = node[1]

    # block devices
    for k, v in s.get_block_devices_raw().items():
        if k.startswith("Reference_Intel"):
            continue
        if v:
            # v is a list of block devices (dictionaries)
            my_dict[k]["block_devices"] = {}
            for idx, d in enumerate(v):
                my_dict[k]["block_devices"][str(idx)] = d

    # disk usage
    for k, v in s.get_disk_usage().items():
        if k.startswith("Reference_Intel"):
            continue
        disks = []
        for line_idx, line in enumerate(v):
            if line_idx == 0:
                headers = line.split()
            else:
                values = line.split()
                line_dict = {}
                for val_idx, value in enumerate(values):
                    if val_idx < len(headers):
                        line_dict[headers[val_idx]] = value
                if line_dict:
                    disks.append(line_dict)
        my_dict[k]["disk_usage"] = {}
        for idx, disk in enumerate(disks):
            my_dict[k]["disk_usage"][str(idx)] = disk

    # processes
    for k, v in s.get_processes().items():
        if k.startswith("Reference_Intel"):
            continue
        processes = []
        for line_idx, line in enumerate(v):
            if line_idx == 0:
                headers = line.split()
            else:
                values = line.split(None, 5)
                line_dict = {}
                for val_idx, value in enumerate(values):
                    if val_idx < len(headers):
                        line_dict[headers[val_idx]] = value.strip()
                processes.append(line_dict)
        my_dict[k]["processes"] = {}
        for idx, process in enumerate(processes):
            my_dict[k]["processes"][str(idx)] = process

    # dump it
    with open(args["output"], "w") as f:
        if len(my_dict) == 1:
            # strip the top-level key
            print(
                json.dumps(my_dict[list(my_dict)[0]], indent=4, sort_keys=True), file=f
            )
        else:
            print(json.dumps(my_dict, indent=4, sort_keys=True), file=f)
