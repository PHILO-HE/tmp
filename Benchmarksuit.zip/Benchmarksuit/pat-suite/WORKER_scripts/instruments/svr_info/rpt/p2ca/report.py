#!/usr/bin/env python
import os, sys, argparse

sys.path.insert(
    0, os.path.abspath(os.path.join(os.path.split(__file__)[0], "..", ".."))
)
from rpt.svrinfo import Svrinfo

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate svr_info p2ca report.")
    parser.add_argument("-i", "--input", help="Raw svr_info log", required=True)
    parser.add_argument(
        "-o", "--output", help="filename for p2ca report", required=True
    )
    args = vars(parser.parse_args())
    if not os.path.isfile(args["input"]):
        raise SystemExit("File not found: " + args["input"])

    s = Svrinfo(args["input"])

    sysInfo = []
    summary_dict = [
        "Host Time",
        "Manufacturer",
        "Product Name",
        "BIOS Version",
        "OS",
        "Kernel",
        "Microcode",
        "Model Name",
        "Sockets",
        "Hyper-Threading Enabled",
        "Total CPU(s)",
        "NUMA Nodes",
        "Turbo Enabled",
        "MemTotal",
    ]

    def get_section(sdict):
        for k in sdict:
            if k.startswith("Reference_Intel"):
                continue
            for e in sdict[k]:
                if e in summary_dict:
                    if e == "MemTotal":
                        total = sdict[k][e].split()
                        totalsize = int(total[0]) / 1024 / 1000
                        sdict[k][e] = str(totalsize) + " GB"
                    sysInfo.append(e + "," + sdict[k][e])
                else:
                    pass

    dimm_dict = {}

    def dimm_topology(dlist):
        dimm_dict["count1"] = 0
        dimm_dict["count2"] = 0
        Type1 = ""
        Type2 = ""
        if not dlist:
            return
        for k in dlist:
            for a in dlist[k]:
                if a["Type"] == "Unknown":
                    continue
                if (Type1 == "") | (Type1 == a["Type"]):
                    Type1 = a["Type"]
                    dimm_dict["size1"] = a["Size"]
                    dimm_dict["speed1"] = a["Speed"]
                    dimm_dict["count1"] += 1
                else:
                    Type2 = a["Type"]
                    dimm_dict["size2"] = a["Size"]
                    dimm_dict["speed2"] = a["Speed"]
                    dimm_dict["count2"] += 1
        if Type1 != "":
            sysInfo.append(
                "DDR Memory Config"
                + ","
                + str(dimm_dict["count1"])
                + " x "
                + dimm_dict["size1"]
                + " "
                + dimm_dict["speed1"]
                + " "
                + Type1
            )
        if Type2 != "":
            sysInfo.append(
                "DCPMM Memory Config"
                + ","
                + str(dimm_dict["count2"])
                + " x "
                + dimm_dict["size2"]
                + " "
                + dimm_dict["speed2"]
                + " "
                + Type2
            )

    get_section(s.get_sys())
    get_section(s.get_sysd())
    get_section(s.get_cpu())
    get_section(s.get_cpu_family())
    get_section(s.get_mem())
    dimm_topology(s.get_dimms())

    # dump it, make sure the file ends with '.csv'
    output_filename = args["output"]
    if ".csv" != output_filename[-4:]:
        output_filename += ".csv"
    with open(output_filename, "w") as f:
        for info in sysInfo:
            f.write(info + "\n")
