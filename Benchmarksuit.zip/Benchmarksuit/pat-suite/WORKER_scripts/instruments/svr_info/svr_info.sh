#!/bin/bash
#
# Copyright (c) 2017, Intel Corporation
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
# 
#     * Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of Intel Corporation nor the names of its contributors
#       may be used to endorse or promote products derived from this software
#       without specific prior written permission.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
VERSION="SVRINFO_DEV_VERSION"

if [ "$BASH_VERSION" = '' ]; then
  echo "Script must be run in bash."
  exit
fi

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root / sudo."
  exit
fi

# CHECK FOR PYTHON INSTALL
if ! [ -x "$(command -v python)" ]; then
  echo "Error: python not found." >&2
  echo "Python version >=2.7.5 or >=3.2 is required."
  exit 1
fi

# CHECK FOR MINIMUM REQUIRED PYTHON VERSION
python -c 'import sys; exit(0 if (sys.version_info >= (2, 7, 5) and sys.version_info < (3, 0)) or sys.version_info >= (3, 2) else 1)'
if [ $? -ne 0 ]; then
  python -V
  echo "Error: Python version >=2.7.5 or >=3.2 is required."
  exit 1
fi

# CHECK FOR MINIMUM REQUIRED KERNEL VERSION
python -c 'import platform; exit(0 if (int(platform.release().split(".")[0]) >= 3) else 1)'
if [ $? -ne 0 ]; then
  uname -r
  echo "Error: Linux Kernel version >=3.0 is required."
  exit 1
fi

PWD=`pwd`
cleanup() {
  cd $PWD
  pkill -P $$ # kill children
  exit
}
trap "cleanup" INT TERM EXIT

SCRIPT_NAME=`basename $0`
SCRIPT_DIR=`dirname "$(readlink -f "$0")"`
RUN_DIR=/tmp/"$SCRIPT_NAME".tmp
FIO_DIR=$RUN_DIR/path_to_fio_disk
SSH_CMD="ssh -o StrictHostKeyChecking=no"
SCP_CMD="scp -o StrictHostKeyChecking=no"

usage(){
  # usage is populated by Makefile from usage.txt
  printf "\nThis is a development version.\n"
  exit 1
}

if [ $# -eq 1 ]; then 
case $1 in
    "--help") usage ;;
    "-h") usage ;;
    "--clean") true ;;
    *) echo Invalid argument used: $1; usage ;;
esac
fi

while [[ $# -gt 0 ]]; do
  key="$1"
  case $key in
    -o|--output)
      REPORTS="$2"
      shift
      ;;
    -c|--check)
      COMPONENTS="$2"
      shift
      ;;
    -n|--nodes)
      NODES="$2"
      shift
      ;;
    --hosts)
      HOSTS_FILE="$2"
      shift
      ;;
    -p|--password)
      PASSWORD="$2"
      shift
      ;;
    -t|--time)
      TIME="$2"
      shift
      ;;
    -s|--serve)
      PORT="$2"
      shift
      ;;
    -f|--fio_disk_path)
      FIO_DIR="$2"
      shift
      ;;
    --clean)
      CLEAN=1
      ;;
    *)
      echo Invalid argument used: $key
      exit
      ;;
  esac
  shift
done

if [ ! -z "$HOSTS_FILE" ]; then
  if [ ! -f "$HOSTS_FILE" ]; then echo "$HOSTS_FILE does not exist";exit;fi
  NODES=''
  for x in `cat $HOSTS_FILE`; do NODES="$x","$NODES";done
fi

if [ "$COMPONENTS" = "all" ] || [ -z $COMPONENTS ]; then
    COMPONENTS="cpu,vm,cache,disk,freq,mem,turbo"
fi

# validate micro-benchmark values
cmps=( "cpu" "vm" "cache" "disk" "freq" "mem" "turbo")
if [ "$COMPONENTS" != "none" ]; then
  for ck in ${COMPONENTS//,/ }; do
    if ! [[ ${cmps[*]} =~ "$ck" ]]; then
      printf "\nInvalid micro-benchmark: %s\n" $ck
      usage
    fi
  done
fi

if [ "$REPORTS" = "all" ] || [ -z $REPORTS ]; then
    REPORTS="html,json,p2ca"
fi

# validate report values
rpts=( "html" "json" "p2ca")
for rpt in ${REPORTS//,/ }; do
  if ! [[ ${rpts[*]} =~ "$rpt" ]]; then
    printf "\nInvalid output format specified: %s\n" $rpt
    usage
  fi
done

if [ -z $NODES ]; then 
  CLEAN=1
  NODES=`hostname`

  # determine relevant reference performance data
  read -r SOCKETS FAMILY MODEL STEPPING <<<$(lscpu | awk '/^Socket.s.:/ {s=$2} /^CPU family:/ {f=$3} /^Model:/ {m=$2} /^Stepping:/ {st=$2} END {print s " " f " " m " " st}')
  if [[ "$FAMILY" -eq "6" ]]; then
    if [[ "$MODEL" -eq "85" ]] && [[ "$STEPPING" -gt "4" ]] && [[ "$STEPPING" -lt "8"  ]]; then 
      ARCH='CLX'
    elif [[ "$MODEL" -eq "85" ]] && [[ "$STEPPING" -le "4" ]]; then
      ARCH="SKX"
    elif [[ "$MODEL" -eq "79" ]]; then
      ARCH="BDX"
    fi
  fi
  if [ -z $ARCH ]; then ARCH="CLX";SOCKETS="2";fi # if better match not available, present comparison to Intel's best
  REFNODE="$SCRIPT_DIR/ref/ref_${SOCKETS}_${ARCH}.txt"
  
  # warn when system is not idle (enough) - Note: checking on local system only when micro-benchmarks will run
  if [ "$COMPONENTS" != "none" ]; then
    IDLE_THRESHOLD=98
    idle=`top -b -n2 | grep "Cpu(s)" | awk 'BEGIN { FS = "," } ; {print $4}' | awk '{print $1}' | tail -n1`
    if (( $(echo "$idle < $IDLE_THRESHOLD" | bc -l) )); then
        echo -e "\e[1;31mWARNING:\e[0m $idle% idle detected. Recommend minimum $IDLE_THRESHOLD% idle for accurate measurement."
    fi
  fi
fi

[ -z "$TIME" ] && TIME=30

if [ ! -z $PASSWORD ]; then 
  SSH_CMD="$SCRIPT_DIR/bin/sshpass -p $PASSWORD ssh -o StrictHostKeyChecking=no"
  SCP_CMD="$SCRIPT_DIR/bin/sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no"
fi

check_bin() {
  ! $SSH_CMD $2 "hash $1 2>/dev/null"
}

check_ssh() {
  $SSH_CMD -o 'PreferredAuthentications=publickey' $1 "hostname" >/dev/null 2>&1
}

ssh_passwordless() {
  if [ "$1" = "localhost" ] || [ "$1" = `hostname` ] || [ ! -z $PASSWORD ]; then return;fi
  if ! check_ssh $1; then
    umask 0077 && mkdir -p ~/.ssh
    SSH_ID=~/.ssh/id_rsa
    [ ! -f $SSH_ID ] && ssh-keygen -t rsa -f $SSH_ID -N '' >/dev/null 2>&1
    [ ! -f $SSH_ID ] && echo "ssh_passwordless keygen failed on $1" && exit 1
    cat "$SSH_ID.pub" | $SSH_CMD $1 'umask 0077; mkdir -p .ssh; cat >> .ssh/authorized_keys'
    if ! check_ssh $1; then echo "ssh_passwordless failed on $1";exit 1;fi
  fi
}

check_installed() {
  ci=$($SSH_CMD $1 "[ -f $RUN_DIR/bin/mlc ] && echo 0 || echo 1")
  check_bin pkill $1 && ci=1 && echo "pkill not installed on $1"
  return $ci
}

chmod +x $SCRIPT_DIR/bin/*
pkg_install() {
    if ! check_installed $1; then
      $SSH_CMD $1 "mkdir -p $RUN_DIR"
      $SCP_CMD -p -r $SCRIPT_DIR/bin $1:$RUN_DIR/.
      $SCP_CMD -p -r $SCRIPT_DIR/lib $1:$RUN_DIR/.
    fi
}

pkg_local() {
    if [ ! -f $RUN_DIR/bin/mlc ]; then
      mkdir -p $RUN_DIR
      cp -a $SCRIPT_DIR/bin $RUN_DIR/.
      cp -a $SCRIPT_DIR/lib $RUN_DIR/.
    fi
}

svr_run() {
  svr_args="-c ${COMPONENTS} -n $1 -t ${TIME} -f ${FIO_DIR}"
  if [ "$1" = "localhost" ] || [ "$1" = `hostname` ]; then 
      pkill svr_info_helper.sh
      \rm -Rf $RUN_DIR/tmp
      mkdir -p $RUN_DIR/tmp
      mkdir -p ${FIO_DIR}
      echo "To monitor progress...in another shell, run: tail -f $RUN_DIR/tmp/$1.txt"
      $RUN_DIR/bin/svr_info_helper.sh $svr_args >$RUN_DIR/tmp/"$1".txt 2>&1 &
  else
      $SSH_CMD $1 "pkill svr_info_helper.sh;\rm -Rf $RUN_DIR/tmp;mkdir -p $RUN_DIR/tmp;mkdir -p ${FIO_DIR};$RUN_DIR/bin/svr_info_helper.sh $svr_args >$RUN_DIR/tmp/"$1".txt 2>&1 &"
  fi
}

gen_report() {
  \rm -f $RUN_DIR/out/svr_info.$1*
  python $SCRIPT_DIR/rpt/$1/report.py -i $RUN_DIR/out/svr_info.txt -o $RUN_DIR/out/svr_info.$1
  \cp $RUN_DIR/out/svr_info.$1* .
  echo "$1 report generated."
}

serve_html() {
  if [ ! -z $PORT ]; then
    pushd $RUN_DIR/out >/dev/null
    hn=`hostname`
    echo "Access html report here: http://$hn:$PORT/svr_info.html" 
    echo "CTRL-C to exit." 
    python -m SimpleHTTPServer $PORT >/dev/null 2>&1
    popd >/dev/null
  fi
}

archive_data() {
  \tar -czf svr_info_out.tar.gz -C $RUN_DIR/out .
  echo "svr_info log and full report is saved in svr_info_out.tar.gz."
}

if [ -n "${CLEAN}" ]; then
for h in ${NODES//,/ }; do
  if [ "$h" = "localhost" ] || [ "$h" = `hostname` ]; then
    \rm -Rf $RUN_DIR
  else
    ssh_passwordless $h
    $SSH_CMD $h "\rm -Rf $RUN_DIR"
  fi
done
fi

mkdir -p $RUN_DIR/out
truncate -s 0 $RUN_DIR/out/svr_info.txt

for hs in ${NODES//,/ }; do
    if [ "$hs" = "localhost" ] || [ "$hs" = `hostname` ]; then
      pkg_local >/dev/null 2>&1
    else 
      ssh_passwordless $hs
      pkg_install $hs >/dev/null 2>&1
    fi
done

echo "Collecting Server Info for $NODES ..."
for hs in ${NODES//,/ }; do
    svr_run $hs
done

echo "Please wait..."
BAR='##############################'
BAR2='------------------------------'
c=0
cn=0
while true; do
  alldone=0
  for hs in ${NODES//,/ }; do
      outfile=$RUN_DIR/tmp/"$hs".txt
      if [ "$hs" = "localhost" ] || [ "$hs" = `hostname` ]; then
        grep -q '^> End: ' $outfile || alldone=1
      else
        $SSH_CMD $hs "grep -q '^> End: ' $outfile" || alldone=1
      fi
  done
  sleep 2
  c=$((c+1))
  cn=$((c/5))
  if [ $cn -gt 29 ];then cn=29;fi
  if [ $cn -lt 1 ];then cn=0;fi
  echo -ne "\rProgress: [${BAR:0:$cn}${BAR2:$cn:30}]" >&2
  if [ $alldone -eq 0 ];then break;fi
done
echo -ne "\rProgress: [${BAR}]\n" >&2

for hs in ${NODES//,/ }; do
    outfile=$RUN_DIR/tmp/"$hs".txt
    if [ "$hs" = "localhost" ] || [ "$hs" = `hostname` ]; then
      cat $outfile >> $RUN_DIR/out/svr_info.txt
    else 
      $SSH_CMD $hs "cat $outfile" >> $RUN_DIR/out/svr_info.txt
    fi
done
printf "\n"

if [ ! -z $REFNODE ] && [ -f $REFNODE ];then cat $REFNODE >> $RUN_DIR/out/svr_info.txt;fi

for rpt in ${REPORTS//,/ }; do
  gen_report $rpt
done
archive_data
serve_html
