#!/bin/bash

#if [ $# -lt 1 ]
#then
#	echo "please provide benchmark log location"
#else
#	result_path=$1
#	cp -r $result_path results/$runid/
#fi

workload=$(awk '(/^CMD_PATH/){for (i=2; i<=NF; i++) print $i}' config)
cp -r $workload results/$runid/
mv $log_dir results/$runid/
cp system_track_list results/$runid/

#collect config files for Hadoop, Spark
if [ $HADOOP_HOME ]; then
	mkdir results/$runid/conf/hadoop
	cp $HADOOP_HOME/etc/hadoop/core-site.xml results/$runid/conf/hadoop/
	cp $HADOOP_HOME/etc/hadoop/hadoop-env.sh results/$runid/conf/hadoop/
	cp $HADOOP_HOME/etc/hadoop/hdfs-site.xml results/$runid/conf/hadoop/
	cp $HADOOP_HOME/etc/hadoop/mapred-site.xml results/$runid/conf/hadoop/
	cp $HADOOP_HOME/etc/hadoop/workers results/$runid/conf/hadoop/
	cp $HADOOP_HOME/etc/hadoop/yarn-site.xml results/$runid/conf/hadoop/
else
	echo "HADOOP_HOME not provided"
fi

if [ $SPARK_HOME ]; then
	mkdir results/$runid/conf/spark
	cp $SPARK_HOME/conf/slaves results/$runid/conf/spark
	cp $SPARK_HOME/conf/spark-defaults.conf results/$runid/conf/spark
	cp $SPARK_HOME/conf/spark-env.sh results/$runid/conf/spark
else
	echo "SPARK_HOME not provided"
fi
