#!/bin/bash

tools/dropCache > $log_dir/test.log
sleep 5
