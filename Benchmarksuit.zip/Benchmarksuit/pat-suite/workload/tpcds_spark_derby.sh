#!/bin/bash

QUERY_DIR=/usr/local/spark/query
format=text
scale=1000
#db=tpcds_s3_${scale}
db=tpcds_spark_${scale}
queries=$(cat $QUERY_DIR/run_order_single.txt)

#clean up result folder
rm -f $QUERY_DIR/spark_parquet_*
rm -f $QUERY_DIR/spark_text_*
rm -f $QUERY_DIR/tpc_stats_${run_id}.log

cd $QUERY_DIR
$work_dir/tools/dropCache
for query in $queries
do
	logname=${log_dir}/spark_${format}_${scale}_${query}
	spark-sql --database $db --name $query -f $query 2>&1 1 > $logname.out | tee $logname.log
	result=$(grep "Time taken" $logname.log | grep -v "INFO")
	echo "$scale $format $query $result" >> ${log_dir}/tpc_stats.log
	$work_dir/tools/dropCache
done
