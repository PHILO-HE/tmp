#!/bin/bash

TeraSort_INPUT="/data/terasort_input"
TeraSort_OUTPUT="/data/terasort_output"
jar="../../workload-tools/terasort/spark-terasort-1.1-SNAPSHOT-jar-with-dependencies.jar"

$work_dir/tools/dropCache
hdfs dfs -rm -r $TeraSort_OUTPUT
start_time=$(date +%s)
spark-submit --class com.github.ehiggs.spark.terasort.TeraSort $jar $TeraSort_INPUT $TeraSort_OUTPUT > $log_dir/terasort.log
end_time=$(date +%s)
DURATION=$((END-START))
echo SortTime = $DURATION seconds
