#!/bin/bash

QUERY_DIR=../workload-tools/TPC-DS/queries
format=text
scale=1000
#db=tpcds_s3_${scale}
db=tpcds_spark_${scale}
queries=$(cat $QUERY_DIR/run_order_test.txt)

$work_dir/tools/dropCache
for query in $queries
do
	logname=${log_dir}/spark_${format}_${scale}_${query}
	spark-sql --database $db --name $query -f ${QUERY_DIR}/${query} 2>&1 1 > $logname.out | tee $logname.log
	result=$(grep "Time taken" $logname.log | grep -v "INFO")
	echo "$scale $format $query $result" >> ${log_dir}/tpc_stats.log
	$work_dir/tools/dropCache
done
